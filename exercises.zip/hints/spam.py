def spamalot():
    print("SPAM " * 100)


# if running as the main script:
    print("I will now spam a lot!")
    spamalot()
