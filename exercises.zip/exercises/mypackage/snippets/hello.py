from . import default_target


def hello(target=default_target):
    print(f"Hello, {target}!")
