import weather_forecast as wf

wf.forecast(
    place="Bern",
    time="00:00:00",
    date="2020-06-10",
    forecast="daily"
)
