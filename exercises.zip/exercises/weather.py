import weather_forecast as wf

wf.forecast(
    place="Bern",
    time="00:00:00",
    date="2021-01-20",
    forecast="daily"
)
