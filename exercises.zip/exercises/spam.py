def spamalot():
    print("SPAM " * 100)


print("I will now spam a lot!")
spamalot()
