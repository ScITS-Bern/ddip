import spam
from spam import spamalot

print("Trying imports...")
spamalot()
spam.spamalot()
