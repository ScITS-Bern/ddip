def spamalot():
    print("SPAM " * 100)


if __name__ == "__main__":
    print("I will now spam a lot!")
    spamalot()
